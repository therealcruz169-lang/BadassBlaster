BadassBlaster - Hosted-ready single file (index.html)

Upload index.html to your GitHub repo root. For GitHub Pages, the game will be available at https://<your-username>.github.io/BadassBlaster/

Made by @Therealcruz94
